#include"shape.h"

void circle()
{
	printf("This is Circle\n");

}
