
#include "shape.h"

int main()
{
	circle();
	square();
	rectangle();

	return 0;
}
