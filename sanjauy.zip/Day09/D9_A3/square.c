#include "shape.h"

void square()
{
	printf("This is Square\n");

}
