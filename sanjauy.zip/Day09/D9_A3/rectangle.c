#include "shape.h"

void rectangle()
{
	printf("This is Rectangle\n");

}
