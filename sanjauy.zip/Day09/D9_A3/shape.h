
#ifndef SHAPE_H
#define SHAPE_H

#include<stdio.h>

void circle();
void square();
void rectangle();

#endif
